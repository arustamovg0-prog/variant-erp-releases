import { createContext, useContext, useReducer, useEffect, useCallback, type ReactNode } from 'react';
import type { Deal, Payment, KPIStats } from '@/types';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { calculateKPI, calculateOverdueDays } from '@/lib/calculations';

// ─── State ────────────────────────────────────────────

interface AppState {
  deals: Deal[];
  payments: Payment[];
  uzsRate: number;
  isLoading: boolean;
}

// ─── Actions ──────────────────────────────────────────

type AppAction =
  | { type: 'SET_DATA'; deals: Deal[]; payments: Payment[] }
  | { type: 'SET_LOADING'; loading: boolean }
  | { type: 'ADD_DEAL'; deal: Deal; payments: Payment[] }
  | { type: 'UPDATE_PAYMENT'; paymentId: string; updates: Partial<Payment> }
  | { type: 'UPDATE_DEAL'; dealId: string; updates: Partial<Deal> }
  | { type: 'SET_UZS_RATE'; rate: number };

// ─── Context ──────────────────────────────────────────

interface AppContextValue {
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  refreshData: () => Promise<void>;
  getAgentDeals: (agentId: string) => Deal[];
  getAgentPayments: (agentId: string) => Payment[];
  getKPIStats: (agentId: string) => KPIStats;
  getDealPayments: (dealId: string) => Payment[];
  getDealById: (dealId: string) => Deal | undefined;
  getPaymentsByStatus: (agentId: string, status: Payment['status']) => Payment[];
  getTodayPayments: (agentId: string) => Payment[];
  getOverduePayments: (agentId: string) => Payment[];
  getUpcomingPayments: (agentId: string) => Payment[];
  getPaymentsInRange: (agentId: string, start: string, end: string) => Payment[];
  getDealsInRange: (agentId: string, start: string, end: string) => Deal[];
  addDealToSupabase: (deal: Deal, payments: Payment[]) => Promise<{ success: boolean; error?: string }>;
  updatePaymentInSupabase: (paymentId: string, updates: Partial<Payment>) => Promise<void>;
  saveUzsRate: (rate: number) => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_DATA':
      return { ...state, deals: action.deals, payments: action.payments, isLoading: false };
    case 'SET_LOADING':
      return { ...state, isLoading: action.loading };
    case 'ADD_DEAL':
      return { ...state, deals: [...state.deals, action.deal], payments: [...state.payments, ...action.payments] };
    case 'UPDATE_PAYMENT':
      return { ...state, payments: state.payments.map(p => p.id === action.paymentId ? { ...p, ...action.updates } : p) };
    case 'UPDATE_DEAL':
      return { ...state, deals: state.deals.map(d => d.id === action.dealId ? { ...d, ...action.updates } : d) };
    case 'SET_UZS_RATE':
      return { ...state, uzsRate: action.rate };
    default:
      return state;
  }
}

// ─── Helper: map Supabase row → Deal ─────────────────

function mapDeal(row: any): Deal {
  return {
    id: row.id,
    agentId: row.agent_id,
    client: row.client,
    phone: row.phone,
    product: row.product,
    totalAmount: Number(row.total_amount),
    monthlyAmount: Number(row.monthly_amount),
    months: row.months,
    paidMonths: row.paid_months,
    startDate: row.start_date,
    status: row.status,
    referral: row.referral_name ? {
      id: `ref-${row.id}`,
      name: row.referral_name,
      phone: row.referral_phone || '',
      relation: row.referral_relation || '',
    } : undefined,
    comment: row.comment || undefined,
  };
}

function mapPayment(row: any): Payment {
  return {
    id: row.id,
    dealId: row.deal_id,
    monthNumber: row.month_number,
    dueDate: row.due_date,
    paidDate: row.paid_date || undefined,
    extendedDate: row.extended_date || undefined,
    amount: Number(row.amount),
    status: row.status,
    overdueDays: row.overdue_days || undefined,
  };
}

export function AppProvider({ children }: { children: ReactNode }) {
  const { agent, isAuthenticated } = useAuth();

  const [state, dispatch] = useReducer(appReducer, {
    deals: [],
    payments: [],
    uzsRate: 12_800,
    isLoading: true,
  });

  // ── Load data from Supabase when authenticated ──

  const refreshData = useCallback(async () => {
    if (!isAuthenticated) return;
    dispatch({ type: 'SET_LOADING', loading: true });

    try {
      // Load deals (RLS filters by agent_id automatically)
      const { data: dealsData, error: dealsError } = await supabase
        .from('deals')
        .select('*')
        .order('created_at', { ascending: false });

      if (dealsError) throw dealsError;

      // Load payments (RLS filters by deal ownership)
      const { data: paymentsData, error: paymentsError } = await supabase
        .from('payments')
        .select('*')
        .order('due_date', { ascending: true });

      if (paymentsError) throw paymentsError;

      // Load UZS rate
      const { data: rateData } = await supabase
        .from('settings')
        .select('value')
        .eq('key', 'uzs_rate')
        .single();

      const deals = (dealsData || []).map(mapDeal);
      const payments = (paymentsData || []).map(mapPayment);

      dispatch({ type: 'SET_DATA', deals, payments });

      if (rateData) {
        dispatch({ type: 'SET_UZS_RATE', rate: Number(rateData.value) });
      }
    } catch (err) {
      console.error('Error loading data:', err);
      dispatch({ type: 'SET_LOADING', loading: false });
    }
  }, [isAuthenticated]);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // ── Supabase CRUD helpers ──

  const addDealToSupabase = async (deal: Deal, payments: Payment[]) => {
    try {
      const { error: dealError } = await supabase.from('deals').insert({
        id: deal.id,
        agent_id: deal.agentId,
        client: deal.client,
        phone: deal.phone,
        product: deal.product,
        total_amount: deal.totalAmount,
        monthly_amount: deal.monthlyAmount,
        months: deal.months,
        paid_months: deal.paidMonths,
        start_date: deal.startDate,
        status: deal.status,
        referral_name: deal.referral?.name || null,
        referral_phone: deal.referral?.phone || null,
        referral_relation: deal.referral?.relation || null,
        comment: deal.comment || null,
      });

      if (dealError) return { success: false, error: dealError.message };

      const paymentRows = payments.map(p => ({
        id: p.id,
        deal_id: p.dealId,
        month_number: p.monthNumber,
        due_date: p.dueDate,
        amount: p.amount,
        status: p.status,
      }));

      const { error: paymentsError } = await supabase.from('payments').insert(paymentRows);

      if (paymentsError) return { success: false, error: paymentsError.message };

      // Update local state
      dispatch({ type: 'ADD_DEAL', deal, payments });
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  };

  const updatePaymentInSupabase = async (paymentId: string, updates: Partial<Payment>) => {
    const dbUpdates: any = {};
    if (updates.status !== undefined) dbUpdates.status = updates.status;
    if (updates.paidDate !== undefined) dbUpdates.paid_date = updates.paidDate;
    if (updates.extendedDate !== undefined) dbUpdates.extended_date = updates.extendedDate;
    if (updates.overdueDays !== undefined) dbUpdates.overdue_days = updates.overdueDays;

    await supabase.from('payments').update(dbUpdates).eq('id', paymentId);
    dispatch({ type: 'UPDATE_PAYMENT', paymentId, updates });
  };

  const saveUzsRate = async (rate: number) => {
    await supabase
      .from('settings')
      .update({ value: String(rate), updated_at: new Date().toISOString(), updated_by: agent?.id })
      .eq('key', 'uzs_rate');
    dispatch({ type: 'SET_UZS_RATE', rate });
  };

  // ── Client-side computed helpers (same as before) ──

  const getAgentDeals = (agentId: string): Deal[] => {
    return state.deals.filter(d => d.agentId === agentId);
  };

  const getAgentPayments = (agentId: string): Payment[] => {
    const dealIds = new Set(getAgentDeals(agentId).map(d => d.id));
    return state.payments.filter(p => dealIds.has(p.dealId));
  };

  const getKPIStats = (agentId: string): KPIStats => {
    return calculateKPI(getAgentDeals(agentId), getAgentPayments(agentId));
  };

  const getDealPayments = (dealId: string): Payment[] => {
    return state.payments.filter(p => p.dealId === dealId).sort((a, b) => a.monthNumber - b.monthNumber);
  };

  const getDealById = (dealId: string): Deal | undefined => {
    return state.deals.find(d => d.id === dealId);
  };

  const getPaymentsByStatus = (agentId: string, status: Payment['status']): Payment[] => {
    return getAgentPayments(agentId).filter(p => p.status === status);
  };

  const getTodayPayments = (agentId: string): Payment[] => {
    const today = new Date().toISOString().split('T')[0];
    return getAgentPayments(agentId).filter(p => {
      const effectiveDate = p.extendedDate || p.dueDate;
      return effectiveDate === today && p.status !== 'paid';
    });
  };

  const getOverduePayments = (agentId: string): Payment[] => {
    return getAgentPayments(agentId)
      .filter(p => p.status === 'overdue' || p.status === 'extended')
      .map(p => ({ ...p, overdueDays: calculateOverdueDays(p.dueDate, p.extendedDate) }))
      .sort((a, b) => (b.overdueDays || 0) - (a.overdueDays || 0));
  };

  const getUpcomingPayments = (agentId: string): Payment[] => {
    const now = new Date();
    const weekLater = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    return getAgentPayments(agentId).filter(p => {
      if (p.status !== 'pending') return false;
      const due = new Date(p.dueDate);
      return due >= now && due <= weekLater;
    });
  };

  const getPaymentsInRange = (agentId: string, start: string, end: string): Payment[] => {
    const startDate = new Date(start);
    const endDate = new Date(end);
    return getAgentPayments(agentId).filter(p => {
      const due = new Date(p.dueDate);
      return due >= startDate && due <= endDate;
    });
  };

  const getDealsInRange = (agentId: string, start: string, end: string): Deal[] => {
    const paymentDealIds = new Set(getPaymentsInRange(agentId, start, end).map(p => p.dealId));
    return getAgentDeals(agentId).filter(d => paymentDealIds.has(d.id));
  };

  return (
    <AppContext.Provider
      value={{
        state,
        dispatch,
        refreshData,
        getAgentDeals,
        getAgentPayments,
        getKPIStats,
        getDealPayments,
        getDealById,
        getPaymentsByStatus,
        getTodayPayments,
        getOverduePayments,
        getUpcomingPayments,
        getPaymentsInRange,
        getDealsInRange,
        addDealToSupabase,
        updatePaymentInSupabase,
        saveUzsRate,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import type { Agent } from '@/types';
import type { User, Session } from '@supabase/supabase-js';

// ─── Context ──────────────────────────────────────────

interface AuthContextValue {
  agent: Agent | null;
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (email: string, password: string, name: string, phone: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [agent, setAgent] = useState<Agent | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Load session on mount and listen for auth changes
  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      handleSession(session);
    });

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      handleSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  async function handleSession(session: Session | null) {
    if (session?.user) {
      setUser(session.user);
      await loadAgentProfile(session.user.id);
    } else {
      setUser(null);
      setAgent(null);
    }
    setIsLoading(false);
  }

  async function loadAgentProfile(userId: string) {
    const { data, error } = await supabase
      .from('agents')
      .select('*')
      .eq('id', userId)
      .single();

    if (data && !error) {
      setAgent({
        id: data.id,
        name: data.name,
        phone: data.phone,
        login: data.login,
        password: '', // never stored on client
      });
    }
  }

  const login = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (data.user) {
        setUser(data.user);
        await loadAgentProfile(data.user.id);
        return { success: true };
      }

      return { success: false, error: 'Неизвестная ошибка' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Ошибка подключения' };
    }
  };

  const signup = async (email: string, password: string, name: string, phone: string) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) {
        return { success: false, error: error.message };
      }

      if (data.user) {
        // Create agent profile
        const { error: profileError } = await supabase
          .from('agents')
          .insert({
            id: data.user.id,
            name,
            phone,
            login: email.split('@')[0],
          });

        if (profileError) {
          return { success: false, error: 'Аккаунт создан, но ошибка при создании профиля: ' + profileError.message };
        }

        setUser(data.user);
        await loadAgentProfile(data.user.id);
        return { success: true };
      }

      return { success: false, error: 'Неизвестная ошибка' };
    } catch (err: any) {
      return { success: false, error: err.message || 'Ошибка подключения' };
    }
  };

  const logout = async () => {
    await supabase.auth.signOut();
    setUser(null);
    setAgent(null);
  };

  return (
    <AuthContext.Provider
      value={{
        agent,
        user,
        isAuthenticated: user !== null && agent !== null,
        isLoading,
        login,
        signup,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

import type { Payment, Deal } from '@/types';
import { formatAmount, formatDate } from './calculations';

export function generateReminderMessage(clientName: string, deal: Deal, payment: Payment): string {
  const amountStr = formatAmount(payment.amount);
  const dateStr = formatDate(payment.extendedDate || payment.dueDate);
  const product = deal.product;

  if (payment.status === 'overdue') {
    return `Уважаемый(ая) ${clientName}! ⚠️\n\nУведомляем вас о просрочке платежа на сумму ${amountStr} за товар "${product}".\n\nПлатеж должен был поступить ${dateStr}.\n\nПросим вас срочно произвести оплату во избежание начисления пени и ухудшения кредитной истории.\n\nС уважением, Variant.`;
  }

  if (payment.status === 'pending') {
    return `Здравствуйте, ${clientName}! 📱\n\nНапоминаем, что ${dateStr} у вас по графику плановый платеж за товар "${product}".\n\nСумма к оплате: ${amountStr}.\n\nПожалуйста, позаботьтесь об оплате заранее. Спасибо, что вы с нами!\n\nС уважением, Variant.`;
  }

  if (payment.status === 'paid') {
    return `Здравствуйте, ${clientName}! ✅\n\nВаш платеж на сумму ${amountStr} за товар "${product}" успешно получен.\n\nСпасибо за своевременную оплату!`;
  }

  return `Здравствуйте, ${clientName}!\n\nИнформация по вашему платежу за "${product}": сумма ${amountStr}, дата ${dateStr}.`;
}

export function getWhatsAppLink(phone: string, text: string): string {
  const cleanPhone = phone.replace(/\D/g, '');
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(text)}`;
}

export function getTelegramLink(phone: string): string {
  // Telegram URL doesn't officially support pre-filling text via phone number web link reliably,
  // so we just link to the contact search.
  const cleanPhone = phone.replace(/\+/g, '');
  return `https://t.me/+${cleanPhone}`;
}

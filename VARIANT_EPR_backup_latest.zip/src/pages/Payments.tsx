import { useState, useMemo } from 'react';
import { useApp } from '@/lib/store';
import { useAuth } from '@/lib/auth';
import ClientCard from '@/components/shared/ClientCard';
import ClientProfileModal from '@/components/shared/ClientProfileModal';
import DealModal from '@/components/shared/DealModal';
import ExtendPaymentModal from '@/components/shared/ExtendPaymentModal';
import type { PaymentStatus, Deal, Payment } from '@/types';
import { Users, Filter } from 'lucide-react';

type FilterStatus = 'all' | PaymentStatus;

const filterOptions: { value: FilterStatus; label: string }[] = [
  { value: 'all', label: 'Все' },
  { value: 'paid', label: 'Оплачен' },
  { value: 'pending', label: 'Ожидается' },
  { value: 'overdue', label: 'Просрочен' },
  { value: 'extended', label: 'Продлён' },
];

interface ClientData {
  name: string;
  phone: string;
  deals: Deal[];
  payments: Payment[];
  status: PaymentStatus;
}

export default function Payments() {
  const { agent } = useAuth();
  const { getAgentDeals, getAgentPayments } = useApp();
  
  const [selectedClient, setSelectedClient] = useState<{name: string, phone: string} | null>(null);
  const [selectedDealId, setSelectedDealId] = useState<string | null>(null);
  const [extendingPayment, setExtendingPayment] = useState<Payment | null>(null);
  const [filter, setFilter] = useState<FilterStatus>('all');
  const [filterYear, setFilterYear] = useState<string>('all');
  const [filterMonth, setFilterMonth] = useState<string>('all');

  if (!agent) return null;

  const agentDeals = getAgentDeals(agent.id);
  const agentPayments = getAgentPayments(agent.id);

  const availableYears = useMemo(() => {
    const years = new Set<string>();
    for (const p of agentPayments) {
       const date = new Date(p.extendedDate || p.dueDate);
       years.add(date.getFullYear().toString());
    }
    const currentYear = new Date().getFullYear();
    years.add(currentYear.toString());
    years.add((currentYear + 1).toString());
    return Array.from(years).sort();
  }, [agentPayments]);

  const monthsList = [
    { value: '1', label: 'Январь' },
    { value: '2', label: 'Февраль' },
    { value: '3', label: 'Март' },
    { value: '4', label: 'Апрель' },
    { value: '5', label: 'Май' },
    { value: '6', label: 'Июнь' },
    { value: '7', label: 'Июль' },
    { value: '8', label: 'Август' },
    { value: '9', label: 'Сентябрь' },
    { value: '10', label: 'Октябрь' },
    { value: '11', label: 'Ноябрь' },
    { value: '12', label: 'Декабрь' },
  ];

  // Group by client and apply year/month filters
  const clientsDataFilteredByTime = useMemo(() => {
    const clientsMap = new Map<string, {
      name: string;
      phone: string;
      deals: Deal[];
      allPayments: Payment[];
      filteredPayments: Payment[];
      status: PaymentStatus;
    }>();

    for (const deal of agentDeals) {
      const key = `${deal.client}-${deal.phone}`;
      if (!clientsMap.has(key)) {
        clientsMap.set(key, { name: deal.client, phone: deal.phone, deals: [], allPayments: [], filteredPayments: [], status: 'paid' });
      }
      clientsMap.get(key)!.deals.push(deal);
    }

    for (const payment of agentPayments) {
      const deal = agentDeals.find(d => d.id === payment.dealId);
      if (deal) {
        const key = `${deal.client}-${deal.phone}`;
        const clientData = clientsMap.get(key);
        if (clientData) {
          clientData.allPayments.push(payment);
          
          const date = new Date(payment.extendedDate || payment.dueDate);
          const matchYear = filterYear === 'all' || date.getFullYear().toString() === filterYear;
          const matchMonth = filterMonth === 'all' || (date.getMonth() + 1).toString() === filterMonth;
          
          if (matchYear && matchMonth) {
            clientData.filteredPayments.push(payment);
          }
        }
      }
    }

    const result = Array.from(clientsMap.values()).filter(c => c.filteredPayments.length > 0);

    for (const data of result) {
      let status: PaymentStatus = 'paid';
      const unpaidPayments = data.filteredPayments.filter(p => p.status !== 'paid');
      
      if (unpaidPayments.some(p => p.status === 'overdue')) {
        status = 'overdue';
      } else if (unpaidPayments.some(p => p.status === 'extended')) {
        status = 'extended';
      } else if (unpaidPayments.some(p => p.status === 'pending')) {
        status = 'pending';
      }
      data.status = status;
    }
    return result;
  }, [agentDeals, agentPayments, filterYear, filterMonth]);

  const filteredClients = useMemo(() => {
    let clients = [...clientsDataFilteredByTime];
    if (filter !== 'all') {
      clients = clients.filter(c => c.status === filter);
    }
    
    // Sort: overdue first, then extended, then pending, then paid
    const statusOrder: Record<string, number> = { overdue: 0, extended: 1, pending: 2, paid: 3 };
    clients.sort((a, b) => {
      const orderDiff = (statusOrder[a.status] ?? 4) - (statusOrder[b.status] ?? 4);
      if (orderDiff !== 0) return orderDiff;
      return a.name.localeCompare(b.name);
    });
    
    return clients;
  }, [clientsDataFilteredByTime, filter]);

  const statusCounts = useMemo(() => {
    const counts: Record<string, number> = { all: clientsDataFilteredByTime.length };
    for (const c of clientsDataFilteredByTime) {
      counts[c.status] = (counts[c.status] || 0) + 1;
    }
    return counts;
  }, [clientsDataFilteredByTime]);

  return (
    <div style={{ maxWidth: '1200px' }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.25rem' }}>
          <Users size={22} style={{ display: 'inline', verticalAlign: 'middle', marginRight: '0.5rem' }} />
          Клиенты и Платежи
        </h1>
        <p style={{ fontSize: '0.875rem', color: 'var(--foreground-muted)' }}>
          Список клиентов с активными графиками • {filteredClients.length} профилей
        </p>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.5rem', flexWrap: 'wrap', alignItems: 'center' }}>
        <Filter size={14} style={{ color: 'var(--foreground-muted)' }} />
        {filterOptions.map(opt => (
          <button
            key={opt.value}
            className={`tab-btn ${filter === opt.value ? 'tab-btn-active' : 'tab-btn-inactive'}`}
            onClick={() => setFilter(opt.value)}
            style={{ fontSize: '0.8125rem' }}
          >
            {opt.label}
            <span style={{ marginLeft: '0.375rem', fontSize: '0.6875rem', opacity: 0.7 }}>
              {statusCounts[opt.value] || 0}
            </span>
          </button>
        ))}

        <div style={{ width: '1px', height: '24px', background: 'var(--border)', margin: '0 0.5rem' }} />

        <select
          value={filterYear}
          onChange={(e) => setFilterYear(e.target.value)}
          className="input-field"
          style={{ width: '120px', padding: '0.375rem 0.75rem', minHeight: '32px' }}
        >
          <option value="all">Все года</option>
          {availableYears.map(year => (
            <option key={year} value={year}>{year}</option>
          ))}
        </select>

        <select
          value={filterMonth}
          onChange={(e) => setFilterMonth(e.target.value)}
          className="input-field"
          style={{ width: '140px', padding: '0.375rem 0.75rem', minHeight: '32px' }}
        >
          <option value="all">Все месяцы</option>
          {monthsList.map(m => (
            <option key={m.value} value={m.value}>{m.label}</option>
          ))}
        </select>
      </div>

      {/* Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))', gap: '1rem' }}>
        {filteredClients.map(client => (
          <ClientCard 
            key={`${client.name}-${client.phone}`}
            name={client.name}
            phone={client.phone}
            deals={client.deals}
            payments={client.filteredPayments}
            allPayments={client.allPayments}
            onClick={(name, phone) => setSelectedClient({ name, phone })}
          />
        ))}
      </div>

      {filteredClients.length === 0 && (
        <div className="glass-card" style={{ padding: '3rem', textAlign: 'center', color: 'var(--foreground-muted)' }}>
          Нет клиентов с выбранным статусом платежей
        </div>
      )}
      
      <ClientProfileModal 
        clientName={selectedClient?.name || null}
        clientPhone={selectedClient?.phone || null}
        onClose={() => setSelectedClient(null)}
        onDealClick={(dealId) => setSelectedDealId(dealId)}
      />

      <ExtendPaymentModal 
        payment={extendingPayment}
        onClose={() => setExtendingPayment(null)}
      />

      <DealModal 
        dealId={selectedDealId}
        onClose={() => setSelectedDealId(null)}
      />
    </div>
  );
}

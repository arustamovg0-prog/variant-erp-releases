import { useState } from 'react';
import { useApp } from '@/lib/store';
import { useAuth } from '@/lib/auth';
import { Settings as SettingsIcon, DollarSign, Save, RefreshCw, LogOut } from 'lucide-react';

export default function Settings() {
  const { agent, logout } = useAuth();
  const { state, saveUzsRate } = useApp();
  const [rateInput, setRateInput] = useState(String(state.uzsRate));
  const [saved, setSaved] = useState(false);

  if (!agent) return null;

  const handleSaveRate = async () => {
    const rate = Number(rateInput);
    if (rate > 0) {
      await saveUzsRate(rate);
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    }
  };

  const handleResetRate = async () => {
    setRateInput('12800');
    await saveUzsRate(12800);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div style={{ maxWidth: '800px' }}>
      <div style={{ marginBottom: '1.5rem' }}>
        <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.25rem' }}>
          <SettingsIcon size={22} style={{ display: 'inline', verticalAlign: 'middle', marginRight: '0.5rem' }} />
          Настройки
        </h1>
        <p style={{ fontSize: '0.875rem', color: 'var(--foreground-muted)' }}>
          Параметры системы
        </p>
      </div>

      {/* Exchange Rate */}
      <div className="glass-card" style={{ padding: '1.5rem', marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1rem' }}>
          <DollarSign size={18} style={{ color: 'var(--primary)' }} />
          <h2 style={{ fontSize: '1rem', fontWeight: 700, fontFamily: 'var(--font-heading)' }}>Курс валют</h2>
        </div>

        <p style={{ fontSize: '0.8125rem', color: 'var(--foreground-muted)', marginBottom: '1rem', lineHeight: 1.6 }}>
          Установите текущий курс UZS за 1 USD. Этот курс используется для отображения сумм в сўмах и в экспорте отчётов.
          Рекомендуется обновлять ежедневно.
        </p>

        <div style={{ display: 'flex', gap: '0.75rem', alignItems: 'flex-end', flexWrap: 'wrap' }}>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--foreground-muted)', display: 'block', marginBottom: '0.375rem' }}>
              1 USD =
            </label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <input
                className="input-field"
                type="number"
                value={rateInput}
                onChange={e => setRateInput(e.target.value)}
                style={{ width: '140px', fontSize: '1rem', fontWeight: 600, fontFamily: 'var(--font-heading)' }}
                min="1"
                step="100"
              />
              <span style={{ fontSize: '0.875rem', color: 'var(--foreground-muted)', fontWeight: 500 }}>сўм</span>
            </div>
          </div>

          <button className="btn-primary" onClick={handleSaveRate}>
            <Save size={14} />
            Сохранить
          </button>

          <button className="btn-secondary" onClick={handleResetRate}>
            <RefreshCw size={14} />
            Сбросить
          </button>

          {saved && (
            <span style={{ fontSize: '0.8125rem', color: 'var(--color-success)', fontWeight: 600, animation: 'fadeIn 0.2s ease' }}>
              ✓ Сохранено
            </span>
          )}
        </div>

        {/* Preview */}
        <div style={{ marginTop: '1rem', padding: '0.75rem', background: 'var(--muted)', borderRadius: 'var(--radius)' }}>
          <div style={{ fontSize: '0.6875rem', fontWeight: 600, color: 'var(--foreground-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '0.5rem' }}>
            Предпросмотр
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '0.5rem' }}>
            {[100, 500, 1000].map(usd => (
              <div key={usd} style={{ display: 'flex', flexDirection: 'column' }}>
                <span style={{ fontSize: '0.875rem', fontWeight: 700, fontFamily: 'var(--font-heading)' }}>${usd}</span>
                <span style={{ fontSize: '0.75rem', color: 'var(--foreground-muted)' }}>
                  {new Intl.NumberFormat('ru-RU').format(usd * (Number(rateInput) || 0))} сўм
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Agent info */}
      <div className="glass-card" style={{ padding: '1.5rem', marginBottom: '1.5rem' }}>
        <h2 style={{ fontSize: '1rem', fontWeight: 700, fontFamily: 'var(--font-heading)', marginBottom: '1rem' }}>Профиль агента</h2>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem' }}>
          <InfoRow label="Имя" value={agent.name} />
          <InfoRow label="Телефон" value={agent.phone} />
          <InfoRow label="Логин" value={agent.login} />
          <InfoRow label="ID" value={agent.id} />
        </div>
      </div>

      {/* Logout */}
      <button
        className="btn-secondary"
        onClick={logout}
        style={{ color: '#f87171', borderColor: 'rgba(239, 68, 68, 0.3)' }}
      >
        <LogOut size={16} />
        Выйти из системы
      </button>
    </div>
  );
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <span style={{ fontSize: '0.6875rem', fontWeight: 600, color: 'var(--foreground-muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</span>
      <div style={{ fontSize: '0.875rem', fontWeight: 600, marginTop: '0.125rem' }}>{value}</div>
    </div>
  );
}

import { useState } from 'react';
import { useApp } from '@/lib/store';
import { useAuth } from '@/lib/auth';
import {
  formatAmount,
  formatAmountUZS,
  formatDate,
  calculateRemaining,
  calculateTotalAmount,
  calculateMonthlyPayment,
  calculateMarkup,
} from '@/lib/calculations';
import StatusBadge from '@/components/shared/StatusBadge';
import DealModal from '@/components/shared/DealModal';
import type { Deal, Payment } from '@/types';
import {
  Plus,
  Search,
  X,
  DollarSign,
  User,
  Phone,
  Package,
  UserCheck,
  MessageSquare,
} from 'lucide-react';

export default function Deals() {
  const { agent } = useAuth();
  const { getAgentDeals, state, dispatch } = useApp();
  const [selectedDealId, setSelectedDealId] = useState<string | null>(null);
  const [showNewDeal, setShowNewDeal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  if (!agent) return null;

  const agentDeals = getAgentDeals(agent.id);

  const filteredDeals = agentDeals.filter(d =>
    d.client.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.product.toLowerCase().includes(searchQuery.toLowerCase()) ||
    d.id.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div style={{ maxWidth: '1200px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
        <div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.25rem' }}>Сделки</h1>
          <p style={{ fontSize: '0.875rem', color: 'var(--foreground-muted)' }}>
            Мои сделки и рассрочки • {agentDeals.length} сделок
          </p>
        </div>
        <button className="btn-primary" onClick={() => setShowNewDeal(true)}>
          <Plus size={16} />
          Новая сделка
        </button>
      </div>

      {/* Search */}
      <div style={{ position: 'relative', marginBottom: '1.5rem' }}>
        <Search size={16} style={{ position: 'absolute', left: '0.75rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--foreground-muted)' }} />
        <input className="input-field" placeholder="Поиск по клиенту, продукту или ID..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} style={{ paddingLeft: '2.25rem' }} />
      </div>

      {/* Table (Desktop) */}
      <div className="glass-card hide-on-mobile" style={{ overflow: 'hidden' }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Клиент</th>
              <th>Продукт</th>
              <th>Сумма (USD)</th>
              <th>Сумма (UZS)</th>
              <th>Срок</th>
              <th>Прогресс</th>
              <th>Остаток</th>
              <th>Статус</th>
              <th>Реферал</th>
            </tr>
          </thead>
          <tbody>
            {filteredDeals.map(deal => {
              const remaining = calculateRemaining(deal, state.payments);
              const progress = deal.months > 0 ? (deal.paidMonths / deal.months) * 100 : 0;
              return (
                <tr key={deal.id} onClick={() => setSelectedDealId(deal.id)} style={{ cursor: 'pointer' }}>
                  <td style={{ fontWeight: 600, fontFamily: 'var(--font-heading)', color: 'var(--primary)' }}>{deal.id}</td>
                  <td>
                    <div style={{ fontWeight: 600 }}>{deal.client}</div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--foreground-muted)' }}>{deal.phone}</div>
                  </td>
                  <td style={{ color: 'var(--foreground-muted)', maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{deal.product}</td>
                  <td style={{ fontWeight: 600, fontFamily: 'var(--font-heading)' }}>{formatAmount(deal.totalAmount)}</td>
                  <td style={{ fontSize: '0.8125rem', color: 'var(--foreground-muted)' }}>{formatAmountUZS(deal.totalAmount)}</td>
                  <td>{deal.months} мес.</td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', minWidth: '120px' }}>
                      <div className="progress-bar" style={{ width: '80px' }}>
                        <div className="progress-fill" style={{ width: `${progress}%`, background: progress >= 100 ? 'var(--color-success)' : 'var(--primary)' }} />
                      </div>
                      <span style={{ fontSize: '0.75rem', color: 'var(--foreground-muted)', whiteSpace: 'nowrap' }}>{deal.paidMonths}/{deal.months}</span>
                    </div>
                  </td>
                  <td style={{ fontWeight: 600 }}>{formatAmount(remaining)}</td>
                  <td><StatusBadge status={deal.status} /></td>
                  <td style={{ fontSize: '0.8125rem', color: 'var(--foreground-muted)' }}>{deal.referral ? deal.referral.name : '—'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Cards (Mobile) */}
      <div className="hide-on-desktop" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        {filteredDeals.map(deal => {
          const remaining = calculateRemaining(deal, state.payments);
          const progress = deal.months > 0 ? (deal.paidMonths / deal.months) * 100 : 0;
          return (
            <div 
              key={deal.id} 
              className="glass-card-interactive" 
              style={{ padding: '1.25rem' }}
              onClick={() => setSelectedDealId(deal.id)}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
                <div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
                    <User size={16} style={{ color: 'var(--primary)' }} />
                    <span style={{ fontSize: '1rem', fontWeight: 600, fontFamily: 'var(--font-heading)' }}>{deal.client}</span>
                  </div>
                  <div style={{ fontSize: '0.8125rem', color: 'var(--foreground-muted)' }}>
                    {deal.id} • {deal.product}
                  </div>
                </div>
                <StatusBadge status={deal.status} />
              </div>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '0.75rem' }}>
                <div style={{ background: 'rgba(30,58,95,0.3)', padding: '0.75rem', borderRadius: '8px' }}>
                  <div style={{ fontSize: '0.6875rem', color: 'var(--foreground-muted)', marginBottom: '0.25rem' }}>Общая сумма</div>
                  <div style={{ fontWeight: 600, fontSize: '0.875rem' }}>{formatAmount(deal.totalAmount)}</div>
                </div>
                <div style={{ background: 'rgba(30,58,95,0.3)', padding: '0.75rem', borderRadius: '8px' }}>
                  <div style={{ fontSize: '0.6875rem', color: 'var(--foreground-muted)', marginBottom: '0.25rem' }}>Остаток</div>
                  <div style={{ fontWeight: 600, fontSize: '0.875rem', color: remaining > 0 ? 'var(--foreground)' : 'var(--color-success)' }}>
                    {formatAmount(remaining)}
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flex: 1, marginRight: '1rem' }}>
                  <div className="progress-bar" style={{ flex: 1 }}>
                    <div className="progress-fill" style={{ width: `${progress}%`, background: progress >= 100 ? 'var(--color-success)' : 'var(--primary)' }} />
                  </div>
                  <span style={{ fontSize: '0.75rem', color: 'var(--foreground-muted)' }}>{deal.paidMonths}/{deal.months}</span>
                </div>
                <div style={{ fontSize: '0.75rem', color: 'var(--foreground-muted)' }}>
                  {deal.months} мес.
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {showNewDeal && agent && <NewDealForm agentId={agent.id} onClose={() => setShowNewDeal(false)} />}
      <DealModal dealId={selectedDealId} onClose={() => setSelectedDealId(null)} />
    </div>
  );
}

// ─── New Deal Form ──────────────────────────────────

function NewDealForm({ agentId, onClose }: { agentId: string; onClose: () => void }) {
  const { addDealToSupabase, state } = useApp();
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState('');

  const [client, setClient] = useState('');
  const [phone, setPhone] = useState('');
  const [product, setProduct] = useState('');
  const [price, setPrice] = useState('');
  const [months, setMonths] = useState('6');
  const [referralName, setReferralName] = useState('');
  const [referralPhone, setReferralPhone] = useState('');
  const [referralRelation, setReferralRelation] = useState('');
  const [comment, setComment] = useState('');

  const priceNum = Number(price) || 0;
  const monthsNum = Number(months) || 1;

  const markup = calculateMarkup(priceNum, monthsNum);
  const totalAmount = calculateTotalAmount(priceNum, monthsNum);
  const monthlyPayment = calculateMonthlyPayment(priceNum, monthsNum);

  const handleSubmit = async () => {
    if (!client || !phone || !product || !price) return;
    setIsSaving(true);
    setSaveError('');

    const newId = `D-${Date.now().toString(36).toUpperCase()}`;
    const startDate = new Date().toISOString().split('T')[0];

    const deal: Deal = {
      id: newId,
      agentId,
      client,
      phone,
      product,
      totalAmount,
      monthlyAmount: monthlyPayment,
      months: monthsNum,
      paidMonths: 0,
      startDate,
      status: 'active',
      comment: comment || undefined,
      referral: referralName ? { id: `R-${Date.now()}`, name: referralName, phone: referralPhone, relation: referralRelation || 'знакомый' } : undefined,
    };

    const payments: Payment[] = [];
    for (let i = 1; i <= monthsNum; i++) {
      const dueDate = new Date(startDate);
      dueDate.setMonth(dueDate.getMonth() + i);
      payments.push({
        id: `P-${newId}-${String(i).padStart(2, '0')}`,
        dealId: newId,
        monthNumber: i,
        dueDate: dueDate.toISOString().split('T')[0],
        amount: monthlyPayment,
        status: 'pending',
      });
    }

    const result = await addDealToSupabase(deal, payments);
    setIsSaving(false);
    if (result.success) {
      onClose();
    } else {
      setSaveError(result.error || 'Ошибка при сохранении');
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '560px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem 1.25rem', borderBottom: '1px solid var(--border)' }}>
          <h2 style={{ fontSize: '1rem', fontWeight: 700, fontFamily: 'var(--font-heading)' }}>Новая сделка</h2>
          <button onClick={onClose} style={{ background: 'var(--muted)', border: '1px solid var(--border)', borderRadius: '8px', padding: '0.375rem', cursor: 'pointer', color: 'var(--foreground-muted)', display: 'flex' }}>
            <X size={16} />
          </button>
        </div>

        <div style={{ padding: '1.25rem', overflowY: 'auto', maxHeight: 'calc(85vh - 140px)' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <SectionLabel icon={<User size={14} />} label="Клиент" />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <InputField label="Имя клиента" value={client} onChange={setClient} placeholder="Алимов Бахтиёр" required />
              <InputField label="Телефон" value={phone} onChange={setPhone} placeholder="+998 90 111 2233" required />
            </div>

            <SectionLabel icon={<Package size={14} />} label="Продукт" />
            <InputField label="Название продукта" value={product} onChange={setProduct} placeholder="iPhone 15 Pro Max" required />

            <SectionLabel icon={<DollarSign size={14} />} label="Финансы" />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <InputField label="Цена (USD)" value={price} onChange={setPrice} placeholder="1200" type="number" required />
              <div>
                <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--foreground-muted)', marginBottom: '0.375rem', display: 'block' }}>Срок (мес.)</label>
                <select className="input-field" value={months} onChange={e => setMonths(e.target.value)} style={{ appearance: 'none' }}>
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(m => <option key={m} value={m}>{m} мес.</option>)}
                </select>
              </div>
            </div>

            {priceNum > 0 && (
              <div className="glass-card" style={{ padding: '1rem' }}>
                <div style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--foreground-muted)', marginBottom: '0.625rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Расчёт наценки</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem' }}>
                  <CalcRow label="Наценка" value={formatAmount(markup)} />
                  <CalcRow label="Итого (USD)" value={formatAmount(totalAmount)} highlight />
                  <CalcRow label="Итого (UZS)" value={formatAmountUZS(totalAmount)} />
                  <CalcRow label="Ежемесячно" value={formatAmount(monthlyPayment)} highlight />
                  <CalcRow label="В UZS/мес" value={formatAmountUZS(monthlyPayment)} />
                  <CalcRow label="Переплата" value={`${((markup / priceNum) * 100).toFixed(1)}%`} />
                </div>
              </div>
            )}

            <SectionLabel icon={<UserCheck size={14} />} label="Реферал (вместо паспорта)" />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              <InputField label="Имя реферала" value={referralName} onChange={setReferralName} placeholder="Рахимов Фаррух" />
              <InputField label="Телефон реферала" value={referralPhone} onChange={setReferralPhone} placeholder="+998 90 555 1234" />
            </div>
            <InputField label="Связь" value={referralRelation} onChange={setReferralRelation} placeholder="друг, коллега, родственник" />

            <SectionLabel icon={<MessageSquare size={14} />} label="Комментарий" />
            <textarea className="input-field" value={comment} onChange={e => setComment(e.target.value)} placeholder="Примечания к сделке..." rows={3} style={{ resize: 'vertical' }} />

            {saveError && (
              <div style={{ padding: '0.5rem 0.75rem', background: 'rgba(239, 68, 68, 0.1)', border: '1px solid rgba(239, 68, 68, 0.3)', borderRadius: 'var(--radius)', fontSize: '0.8125rem', color: '#f87171' }}>
                {saveError}
              </div>
            )}

            <div style={{ position: 'sticky', bottom: '-1.25rem', padding: '1rem 0', background: 'var(--card)', zIndex: 10, marginTop: '1rem', borderTop: '1px solid var(--border)' }}>
              <button className="btn-primary" onClick={handleSubmit} disabled={!client || !phone || !product || !price || isSaving} style={{ width: '100%', padding: '0.75rem', opacity: !client || !phone || !product || !price || isSaving ? 0.5 : 1 }}>
                <Plus size={16} />
                {isSaving ? 'Сохранение...' : 'Создать сделку'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function InputField({ label, value, onChange, placeholder, type = 'text', required }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; type?: string; required?: boolean }) {
  return (
    <div>
      <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--foreground-muted)', marginBottom: '0.375rem', display: 'block' }}>
        {label} {required && <span style={{ color: 'var(--color-danger)' }}>*</span>}
      </label>
      <input className="input-field" type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} />
    </div>
  );
}

function SectionLabel({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.8125rem', fontWeight: 700, fontFamily: 'var(--font-heading)', color: 'var(--foreground)', paddingTop: '0.25rem' }}>
      <span style={{ color: 'var(--primary)' }}>{icon}</span>
      {label}
    </div>
  );
}

function CalcRow({ label, value, highlight }: { label: string; value: string; highlight?: boolean }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <span style={{ fontSize: '0.75rem', color: 'var(--foreground-muted)' }}>{label}</span>
      <span style={{ fontSize: highlight ? '0.875rem' : '0.8125rem', fontWeight: highlight ? 700 : 500, fontFamily: 'var(--font-heading)', color: highlight ? 'var(--foreground)' : 'var(--foreground-muted)' }}>{value}</span>
    </div>
  );
}

import { useState, useMemo } from 'react';
import { useApp } from '@/lib/store';
import { useAuth } from '@/lib/auth';
import { formatAmount, formatAmountUZS, formatPercent, formatDate } from '@/lib/calculations';
import { exportExcel, exportCSV } from '@/lib/export';
import KPICard from '@/components/shared/KPICard';
import StatusBadge from '@/components/shared/StatusBadge';
import {
  FileBarChart,
  Download,
  FileSpreadsheet,
  Calendar,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  CreditCard,
} from 'lucide-react';

export default function Reports() {
  const { agent } = useAuth();
  const { state, getPaymentsInRange, getDealsInRange } = useApp();

  const defaultEnd = new Date().toISOString().split('T')[0];
  const defaultStart = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

  const [startDate, setStartDate] = useState(defaultStart);
  const [endDate, setEndDate] = useState(defaultEnd);

  if (!agent) return null;

  const rangePayments = useMemo(() => getPaymentsInRange(agent.id, startDate, endDate), [agent.id, startDate, endDate, getPaymentsInRange]);
  const rangeDeals = useMemo(() => getDealsInRange(agent.id, startDate, endDate), [agent.id, startDate, endDate, getDealsInRange]);

  const kpi = useMemo(() => {
    const totalDeals = rangeDeals.length;
    const totalPayments = rangePayments.length;
    const dueAmount = rangePayments.reduce((s, p) => s + p.amount, 0);
    const paidPayments = rangePayments.filter(p => p.status === 'paid');
    const paidAmount = paidPayments.reduce((s, p) => s + p.amount, 0);
    const overduePayments = rangePayments.filter(p => p.status === 'overdue');
    const overdueAmount = overduePayments.reduce((s, p) => s + p.amount, 0);
    const collectionRate = dueAmount > 0 ? (paidAmount / dueAmount) * 100 : 0;

    return { totalDeals, totalPayments, dueAmount, paidAmount, overdueAmount, overduePayments: overduePayments.length, collectionRate };
  }, [rangePayments, rangeDeals]);

  const handleExportExcel = () => {
    exportExcel(rangeDeals, rangePayments, startDate, endDate, state.uzsRate);
  };

  const handleExportCSV = () => {
    exportCSV(rangeDeals, rangePayments, startDate, endDate, state.uzsRate);
  };

  return (
    <div style={{ maxWidth: '1200px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '1.5rem' }}>
        <div>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: '0.25rem' }}>
            <FileBarChart size={22} style={{ display: 'inline', verticalAlign: 'middle', marginRight: '0.5rem' }} />
            Отчёты
          </h1>
          <p style={{ fontSize: '0.875rem', color: 'var(--foreground-muted)' }}>
            Аналитика и экспорт за выбранный период
          </p>
        </div>
      </div>

      {/* Period selector + Export */}
      <div className="glass-card" style={{ padding: '1rem 1.25rem', marginBottom: '1.5rem', display: 'flex', alignItems: 'flex-end', gap: '1rem', flexWrap: 'wrap' }}>
        <div>
          <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--foreground-muted)', display: 'block', marginBottom: '0.375rem' }}>
            <Calendar size={12} style={{ display: 'inline', verticalAlign: 'middle', marginRight: '0.25rem' }} />
            Дата начала
          </label>
          <input className="input-field" type="date" value={startDate} onChange={e => setStartDate(e.target.value)} style={{ width: '180px' }} />
        </div>
        <div>
          <label style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--foreground-muted)', display: 'block', marginBottom: '0.375rem' }}>
            <Calendar size={12} style={{ display: 'inline', verticalAlign: 'middle', marginRight: '0.25rem' }} />
            Дата окончания
          </label>
          <input className="input-field" type="date" value={endDate} onChange={e => setEndDate(e.target.value)} style={{ width: '180px' }} />
        </div>
        <div style={{ flex: 1 }} />
        <button className="btn-primary" onClick={handleExportExcel}>
          <FileSpreadsheet size={16} />
          Excel (.xlsx)
        </button>
        <button className="btn-secondary" onClick={handleExportCSV}>
          <Download size={16} />
          CSV
        </button>
      </div>

      {/* Period KPI */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginBottom: '2rem' }}>
        <KPICard label="Сделок за период" value={String(kpi.totalDeals)} icon={<DollarSign size={20} />} accentColor="var(--primary)" />
        <KPICard label="Платежей" value={String(kpi.totalPayments)} icon={<CreditCard size={20} />} accentColor="var(--color-info)" />
        <KPICard label="Сумма к оплате" value={formatAmount(kpi.dueAmount)} subtitle={formatAmountUZS(kpi.dueAmount)} icon={<DollarSign size={20} />} accentColor="var(--color-warning)" />
        <KPICard label="Оплачено" value={formatAmount(kpi.paidAmount)} subtitle={formatAmountUZS(kpi.paidAmount)} icon={<CheckCircle size={20} />} accentColor="var(--color-success)" />
        <KPICard label="Просрочено" value={formatAmount(kpi.overdueAmount)} subtitle={`${kpi.overduePayments} платежей`} icon={<AlertTriangle size={20} />} accentColor="var(--color-danger)" />
        <KPICard label="Собираемость" value={formatPercent(kpi.collectionRate)} icon={<TrendingUp size={20} />} accentColor={kpi.collectionRate >= 80 ? 'var(--color-success)' : 'var(--color-warning)'} />
      </div>

      {/* Table */}
      <div className="glass-card" style={{ overflow: 'hidden' }}>
        <div style={{ padding: '1rem 1.25rem', borderBottom: '1px solid var(--border)' }}>
          <h2 style={{ fontSize: '0.9375rem', fontWeight: 700, fontFamily: 'var(--font-heading)' }}>
            Детали платежей за период
          </h2>
          <span style={{ fontSize: '0.75rem', color: 'var(--foreground-muted)' }}>
            {formatDate(startDate)} — {formatDate(endDate)} • {rangePayments.length} записей
          </span>
        </div>

        <div style={{ overflowX: 'auto' }}>
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Клиент</th>
                <th>Продукт</th>
                <th>Месяц</th>
                <th>Сумма (USD)</th>
                <th>Сумма (UZS)</th>
                <th>Статус</th>
                <th>Дата</th>
                <th>Продление</th>
                <th>Просрочка</th>
              </tr>
            </thead>
            <tbody>
              {rangePayments.map(payment => {
                const deal = state.deals.find(d => d.id === payment.dealId);
                if (!deal) return null;
                return (
                  <tr key={payment.id}>
                    <td style={{ fontWeight: 600, fontFamily: 'var(--font-heading)', color: 'var(--primary)' }}>{deal.id}</td>
                    <td>{deal.client}</td>
                    <td style={{ color: 'var(--foreground-muted)', maxWidth: '180px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{deal.product}</td>
                    <td>{payment.monthNumber}</td>
                    <td style={{ fontWeight: 600, fontFamily: 'var(--font-heading)' }}>{formatAmount(payment.amount)}</td>
                    <td style={{ fontSize: '0.8125rem', color: 'var(--foreground-muted)' }}>{formatAmountUZS(payment.amount)}</td>
                    <td><StatusBadge status={payment.status} /></td>
                    <td style={{ fontSize: '0.8125rem', color: 'var(--foreground-muted)' }}>{payment.paidDate ? formatDate(payment.paidDate) : formatDate(payment.dueDate)}</td>
                    <td style={{ fontSize: '0.8125rem', color: payment.extendedDate ? '#60a5fa' : 'var(--foreground-muted)' }}>{payment.extendedDate ? formatDate(payment.extendedDate) : '—'}</td>
                    <td>{payment.overdueDays && payment.overdueDays > 0 ? <span style={{ color: '#f87171', fontWeight: 600, fontSize: '0.8125rem' }}>{payment.overdueDays} дн.</span> : '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {rangePayments.length === 0 && (
          <div style={{ padding: '3rem', textAlign: 'center', color: 'var(--foreground-muted)' }}>
            Нет платежей за выбранный период
          </div>
        )}
      </div>
    </div>
  );
}

import { useState } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { X, CalendarClock } from 'lucide-react';
import type { Payment } from '@/types';
import { useApp } from '@/lib/store';
import { formatDate, formatAmount } from '@/lib/calculations';

interface ExtendPaymentModalProps {
  payment: Payment | null;
  onClose: () => void;
}

export default function ExtendPaymentModal({ payment, onClose }: ExtendPaymentModalProps) {
  const { updatePaymentInSupabase } = useApp();
  const [newDate, setNewDate] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  if (!payment) return null;

  const currentDueDate = payment.extendedDate || payment.dueDate;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDate) {
      setError('Выберите новую дату');
      return;
    }

    const selectedDate = new Date(newDate);
    const currentDate = new Date(currentDueDate);

    if (selectedDate <= currentDate) {
      setError('Новая дата должна быть позже текущей даты платежа');
      return;
    }

    setIsSubmitting(true);
    setError('');

    try {
      await updatePaymentInSupabase(payment.id, {
        extendedDate: newDate,
        status: 'extended',
      });
      onClose();
    } catch (err: any) {
      setError(err.message || 'Ошибка при продлении платежа');
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog.Root open={!!payment} onOpenChange={(open) => !open && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay className="dialog-overlay" />
        <Dialog.Content className="dialog-content" style={{ maxWidth: '400px' }}>
          <div className="dialog-header">
            <Dialog.Title className="dialog-title">
              <CalendarClock size={20} style={{ display: 'inline', marginRight: '0.5rem', color: 'var(--primary)' }} />
              Продлить платеж
            </Dialog.Title>
            <Dialog.Close className="dialog-close">
              <X size={20} />
            </Dialog.Close>
          </div>

          <div style={{ padding: '1.5rem' }}>
            <div style={{ marginBottom: '1.5rem', background: 'rgba(30, 58, 95, 0.3)', padding: '1rem', borderRadius: '8px' }}>
              <div style={{ fontSize: '0.8125rem', color: 'var(--foreground-muted)', marginBottom: '0.25rem' }}>Сумма платежа</div>
              <div style={{ fontSize: '1.25rem', fontWeight: 700, fontFamily: 'var(--font-heading)' }}>
                {formatAmount(payment.amount)}
              </div>
              
              <div style={{ marginTop: '0.75rem', fontSize: '0.8125rem', color: 'var(--foreground-muted)' }}>Текущая дата оплаты</div>
              <div style={{ fontSize: '0.9375rem', fontWeight: 500 }}>
                {formatDate(currentDueDate)}
              </div>
            </div>

            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: '1.5rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                <label style={{ fontSize: '0.875rem', fontWeight: 500, color: 'var(--foreground)' }}>Новая дата оплаты</label>
                <input
                  type="date"
                  className="input-field"
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  min={currentDueDate}
                  required
                  style={{
                    colorScheme: 'dark', /* Helps native date picker blend with dark theme */
                    padding: '0.75rem',
                    fontSize: '1rem'
                  }}
                />
              </div>

              {error && (
                <div style={{ color: '#ef4444', fontSize: '0.875rem', marginBottom: '1rem' }}>
                  {error}
                </div>
              )}

              <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1.5rem' }}>
                <button
                  type="button"
                  className="btn btn-secondary"
                  style={{ flex: 1 }}
                  onClick={onClose}
                  disabled={isSubmitting}
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  style={{ flex: 1 }}
                  disabled={isSubmitting || !newDate}
                >
                  {isSubmitting ? 'Сохранение...' : 'Продлить'}
                </button>
              </div>
            </form>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

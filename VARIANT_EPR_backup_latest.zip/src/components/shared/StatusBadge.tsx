import type { PaymentStatus } from '@/types';

interface StatusBadgeProps {
  status: PaymentStatus | string;
}

const statusConfig: Record<string, { label: string; className: string }> = {
  paid: { label: 'Оплачен', className: 'status-paid' },
  pending: { label: 'Ожидается', className: 'status-pending' },
  overdue: { label: 'Просрочен', className: 'status-overdue' },
  extended: { label: 'Продлён', className: 'status-extended' },
  active: { label: 'Активна', className: 'status-pending' },
  completed: { label: 'Завершена', className: 'status-paid' },
};

export default function StatusBadge({ status }: StatusBadgeProps) {
  const config = statusConfig[status] || { label: status, className: 'status-pending' };
  return (
    <span className={`status-badge ${config.className}`}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'currentColor' }} />
      {config.label}
    </span>
  );
}

import { useAuth } from '@/lib/auth';
import {
  LayoutDashboard,
  CreditCard,
  Activity,
  FileBarChart,
  Handshake,
  Shield,
  Settings,
  LogOut,
  Users,
} from 'lucide-react';

interface SidebarProps {
  activeSection: string;
  onNavigate: (section: string) => void;
}

const navItems = [
  { id: 'dashboard', label: 'Обзор', icon: LayoutDashboard },
  { id: 'clients', label: 'База клиентов', icon: Users },
  { id: 'deals', label: 'Сделки', icon: Handshake },
  { id: 'payments', label: 'Платежи', icon: CreditCard },
  { id: 'monitoring', label: 'Мониторинг', icon: Activity },
  { id: 'reports', label: 'Отчёты', icon: FileBarChart },
];

export default function Sidebar({ activeSection, onNavigate }: SidebarProps) {
  const { agent, logout } = useAuth();

  return (
    <aside
      className="sidebar"
      style={{
        width: '260px',
        minHeight: '100vh',
        background: 'var(--background-secondary)',
        borderRight: '1px solid var(--border)',
        padding: '1.5rem 1rem',
        display: 'flex',
        flexDirection: 'column',
      }}
    >
      {/* Logo */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', padding: '0 0.5rem', marginBottom: '2rem' }}>
        <div style={{ width: '36px', height: '36px', borderRadius: '8px', background: 'linear-gradient(135deg, var(--primary), var(--secondary))', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Shield size={20} color="#fff" />
        </div>
        <div className="logo-text">
          <h1 style={{ fontSize: '1rem', fontWeight: 700, fontFamily: 'var(--font-heading)', color: 'var(--foreground)', lineHeight: 1.2 }}>
            Trust-Network
          </h1>
          <span style={{ fontSize: '0.625rem', fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--primary)' }}>
            ERP Platform
          </span>
        </div>
      </div>

      {/* Navigation */}
      <nav style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem', flex: 1 }}>
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              className={`sidebar-link ${isActive ? 'active' : ''}`}
              onClick={() => onNavigate(item.id)}
              style={{ border: 'none', textAlign: 'left', background: isActive ? undefined : 'transparent' }}
            >
              <Icon size={18} />
              <span className="sidebar-text">{item.label}</span>
            </button>
          );
        })}

        {/* Settings - separated */}
        <div style={{ marginTop: '0.5rem', paddingTop: '0.5rem', borderTop: '1px solid var(--border)' }}>
          <button
            className={`sidebar-link ${activeSection === 'settings' ? 'active' : ''}`}
            onClick={() => onNavigate('settings')}
            style={{ border: 'none', textAlign: 'left', background: activeSection === 'settings' ? undefined : 'transparent' }}
          >
            <Settings size={18} />
            <span className="sidebar-text">Настройки</span>
          </button>
        </div>
      </nav>

      {/* Agent footer */}
      {agent && (
        <div style={{ padding: '1rem 0.5rem', borderTop: '1px solid var(--border)', marginTop: '1rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem', marginBottom: '0.625rem' }}>
            <div style={{ width: '32px', height: '32px', borderRadius: '50%', background: 'linear-gradient(135deg, var(--primary), var(--navy-600, #2d5280))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '0.7rem', fontWeight: 700, color: '#fff', flexShrink: 0 }}>
              {agent.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
            </div>
            <div className="sidebar-text" style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: '0.8125rem', fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{agent.name}</div>
              <div style={{ fontSize: '0.6875rem', color: 'var(--foreground-muted)' }}>Агент</div>
            </div>
          </div>
          <button
            onClick={logout}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              fontSize: '0.75rem',
              color: 'var(--foreground-muted)',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: '0.25rem 0',
              transition: 'color 0.15s',
            }}
            onMouseEnter={e => (e.currentTarget.style.color = '#f87171')}
            onMouseLeave={e => (e.currentTarget.style.color = 'var(--foreground-muted)')}
          >
            <LogOut size={14} />
            <span className="sidebar-text">Выйти</span>
          </button>
        </div>
      )}
    </aside>
  );
}

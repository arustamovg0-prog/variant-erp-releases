import type { ReactNode } from 'react';
import Sidebar from './Sidebar';
import { LayoutDashboard, Handshake, CreditCard, Users, Settings } from 'lucide-react';

interface AppLayoutProps {
  activeSection: string;
  onNavigate: (section: string) => void;
  children: ReactNode;
}

export default function AppLayout({ activeSection, onNavigate, children }: AppLayoutProps) {
  const bottomNavItems = [
    { id: 'dashboard', label: 'Обзор', icon: LayoutDashboard },
    { id: 'clients', label: 'Клиенты', icon: Users },
    { id: 'deals', label: 'Сделки', icon: Handshake },
    { id: 'payments', label: 'Платежи', icon: CreditCard },
    { id: 'settings', label: 'Меню', icon: Settings },
  ];

  return (
    <div className="app-container" style={{ display: 'flex', minHeight: '100vh', width: '100%' }}>
      <Sidebar activeSection={activeSection} onNavigate={onNavigate} />
      
      <main
        style={{
          flex: 1,
          padding: '1.5rem',
          overflowY: 'auto',
          maxHeight: '100vh',
          background: 'var(--background)',
          width: '100%',
        }}
      >
        {children}
      </main>

      {/* Bottom Navigation for Mobile */}
      <nav className="hide-on-desktop bottom-nav">
        {bottomNavItems.map(item => {
          const Icon = item.icon;
          const isActive = activeSection === item.id || (activeSection === 'monitoring' && item.id === 'payments');
          return (
            <button
              key={item.id}
              className={`bottom-nav-item ${isActive ? 'active' : ''}`}
              onClick={() => onNavigate(item.id)}
            >
              <Icon size={20} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
